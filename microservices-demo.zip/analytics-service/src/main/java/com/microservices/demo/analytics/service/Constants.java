package com.microservices.demo.analytics.service;

public class Constants {
    public static final String NA = "N/A";
}
