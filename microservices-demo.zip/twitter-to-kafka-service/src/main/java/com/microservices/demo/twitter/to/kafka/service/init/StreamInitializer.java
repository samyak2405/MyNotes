package com.microservices.demo.twitter.to.kafka.service.init;

public interface StreamInitializer {
    void init();
}
